<?php
session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="Web stranica o John Mayeru">
        <meta name="keywords" content="John,Mayer,gitara,glazba">
        <meta name="author" content="Marko Kralj">
        <title>John Mayer</title>
        <link rel="icon" href="../images/icogif.gif" type="image/gif">
        <link rel="stylesheet" href="style.css">
        <style>
            a:link{color: purple;}
            a:visited{color: rgb(108, 29, 116);}
            a:hover{color: wheat;}
            a:active{color: violet;}</style>
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@300&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Teko:wght@600&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/b05e340512.js" crossorigin="anonymous"></script>
    </head>

    <main>
        <header>
            <h1>Webshop</h1>
            <h2 class="akcija">AKCIJA NA MAJICE!</h1>
        </header>

        <section class="navigacija1">
            <nav class="navigacija1">
                <ul>
                    <li><a href="../index.php">Naslovnica</a></li>
                    <li><a href="../Kontakt/Kontakt.php">Kontakt</a></li>
                    <li><a href="../O njemu/O njemu.php">O njemu</a></li>
                    <li><a href="../Novosti/Novosti.php">Novosti</a></pre></li>
                    <li><a href="#">Webshop</a></pre></li>
                    <li><?php if(isset($_SESSION["userid"])){
                        echo '<a href="../logout.php">Log out</a></div>';
                    }else{
                        echo '<a href="../login/index.php">Login/Sign Up</a></div>';
                        
                    }
                    ?></li>
                </ul>
            </nav> 
        </section>
        
        <section class="shop">
            <div class="proizvod">
                
                <img src="../proizvodi/big_shirt1.jpg" alt="big_shirt_ljubicasta" width="100%">
                <h3>I Got A Big Shirt - ljubičasta</h3>
                <h4>100% pamuk, majica dugih rukava sa Big Shirt grafikom i I Got A Big Shirt John Mayer Tour 2019 ispisom na leđima.</h4>
                <p class="cijena_prekrizena">320 KN</p><p class="cijena_akcija">224 KN</p>
                <div class="clear"></div>
                <button>Dodaj u košaricu</button>
            </div>

            <div class="proizvod">
                
                <img src="../proizvodi/big_shirt2.jpg" alt="big_shirt_bijela" width="100%">
                <h3>I Got A Big Shirt - bijela</h3>
                <h4>100% pamuk, majica dugih rukava sa Big Shirt grafikom i I Got A Big Shirt John Mayer Tour 2019 ispisom na leđima.</h4>
                <p class="cijena_prekrizena">320 KN</p><p class="cijena_akcija">224 KN</p>
                <div class="clear"></div>
                <button>Dodaj u košaricu</button>
            </div>

            <div class="proizvod">
                
                <img src="../proizvodi/t-shirt1.jpg" alt="t-shirt1" width="100%">
                <h3>JM Battle Studies majica kratkih rukava</h3>
                <h4>JM Battle Studies ženska majica sa V izrezom u krem boji.</h4>
                <p class="cijena_prekrizena">160 KN</p><p class="cijena_akcija">112 KN</p>
                <div class="clear"></div>
                <button>Dodaj u košaricu</button>
            </div>

            <div class="proizvod">
                
                <img src="../proizvodi/vinyl.jpg" alt="ploca" width="100%">
                <h3>WHERE THE LIGHT IS gramofonska ploča</h3>
                <h4>4 ploče, koncert u Los Angelesu iz 2007. godine.</h4>
                <p class="cijena">370 KN</p><p class="cijena_hidden">$35</p>
                <div class="clear"></div>
                <button>Dodaj u košaricu</button>
            </div>

            <div class="proizvod">
                
                <img src="../proizvodi/vinyl1.jpg" alt="ploca2" width="100%">
                <h3>ROOM FOR SQUARES gramofonska ploča</h3>
                <h4>1 ploča, sadrži 13 pjesama.</h4>
                <p class="cijena">130 KN</p><p class="cijena_hidden">$35</p>
                <div class="clear"></div>
                <button>Dodaj u košaricu</button>
            </div>

            <div class="proizvod">
                
                <img src="../proizvodi/mug.jpg" alt="mug" width="100%">
                <h3>Floral emajlna šalica</h3>
                <h4>Vintage emajlna šalica sa novim JM Flowers dizajnom.</h4>
                <p class="cijena">90 KN</p><p class="cijena_hidden">$35</p>
                <div class="clear"></div>
                <button>Dodaj u košaricu</button>
            </div>

            <div class="proizvod">
                
                <img src="../proizvodi/album.jpg" alt="album" width="100%">
                <h3>Paradise Valley (Gold Series) CD</h3>
                <h4>Paradise Valley CD u originalnom pakiranju.</h4>
                <p class="cijena">100 KN</p><p class="cijena_hidden">$35</p>
                <div class="clear"></div>
                <button>Dodaj u košaricu</button>
            </div>

            <div class="proizvod">
                
                <img src="../proizvodi/deka.jpg" alt="deka" width="100%">
                <h3>Pendleton deka</h3>
                <h4>Pendleton deka sa JM Logo uzorkom.</h4>
                <p class="cijena">799 KN</p><p class="cijena_hidden">$35</p>
                <div class="clear"></div>
                <button>Dodaj u košaricu</button>
            </div>

            <div class="proizvod">
                
                <img src="../proizvodi/silterica.jpg" alt="silterica" width="100%">
                <h3>JMC Logo šilterica</h3>
                <h4>Podesiva crna šilterica.</h4>
                <p class="cijena">159 KN</p><p class="cijena_hidden">$35</p>
                <div class="clear"></div>
                <button>Dodaj u košaricu</button>
            </div>
        </section>
    </main>
</html>
