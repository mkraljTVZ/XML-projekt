<?php

$username=$_POST['name'];
$pass=$_POST['pass'];
$con_pass=$_POST['con_pass'];
$mail=$_POST['mail'];


//provjera lozinki
if($pass!==$con_pass){
    header("location:index.php?error=GreskaLozinka");
    exit();
}

//provjera jel mail ili username koristen
$xml=simplexml_load_file("users.xml");
$ispravno=true;
foreach($xml->korisnik as $kor){
    $koruser=$kor->username;
    $kormail=$kor->mail;


    if($koruser==$username || $kormail==$mail){
        header("location:index.php?error=GreskaKoristeniMailUsername");
        exit();
    }
}

//Otvaranje xml datoteke



//Upisivanje u XML
$xmlstr=simplexml_load_file("users.xml");
$broj=0;
foreach($xml->korisnik as $kor){
    $broj+=1;
}


$xmlstr->addChild('korisnik',' ');
$xmlstr->korisnik[$broj]->addChild('username',$username);
$xmlstr->korisnik[$broj]->addChild('lozinka',$pass);
$xmlstr->korisnik[$broj]->addChild('mail',$mail);
$xmlstr->asXml("users.xml");

header("location:../index.php?result=UspjesnaReg");



?>