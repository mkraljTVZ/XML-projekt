<?php

//Lozinka
$pass=$_POST['pass'];
$mail=$_POST['email'];
$uspjesno=false;
$xml=simplexml_load_file("users.xml");
foreach($xml->korisnik as $kor){
    $koruser=$kor->username;
    $kormail=$kor->mail;
    $korloz=$kor->lozinka;

    if(isset($_POST["submit"])){
        if($korloz==$pass && $kormail==$mail){
            $uspjesno=true;
            session_start();
            $_SESSION["userid"]=$koruser;
            $_SESSION["useruid"]=$kormail;
            header("location:../index.php?result=UspjesnaPrijava");
            exit();

        }
        
    }

}
if(!$uspjesno){
    header("location:index.php?result=NetocniPodaci");
    exit();}

?>