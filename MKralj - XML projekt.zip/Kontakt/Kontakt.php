<?php
session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="Web stranica o John Mayeru">
        <meta name="keywords" content="John,Mayer,gitara,glazba">
        <meta name="author" content="Marko Kralj">
        <title>John Mayer</title>
        <link rel="icon" href="../images/icogif.gif" type="image/gif">
        <link rel="stylesheet" href="style.css">
        <style>
            a:link{color: purple;}
            a:visited{color: rgb(108, 29, 116);}
            a:hover{color: wheat;}
            a:active{color: violet;}</style>
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@300&display=swap" rel="stylesheet">
                <link href="https://fonts.googleapis.com/css2?family=Teko:wght@600&display=swap" rel="stylesheet">
                <script src="https://kit.fontawesome.com/b05e340512.js" crossorigin="anonymous"></script>
    </head>

    <body>
    <header>
        <div class="navigacija"><pre><a href="../index.php">Naslovnica</a>    <a href="#">Kontakt</a>    <a href="../O njemu/O njemu.php">O njemu</a>    <a href="../Novosti/Novosti.php">Novosti</a>    <a href="../Trgovina/trgovina.php">Webshop</a>
    
        <?php if(isset($_SESSION["userid"])){
            echo '<a href="../logout.php">Log out</a></div>';
        }else{
            echo '<a href="../login/index.php">Login/Sign Up</a></div>';
            
        }
        ?>
    </pre></div>
        
        <div>
        <img src="../images/ico1edit.jpg" height="200" alt="logo" class="slikica">
        <h1 class="naslov">John Mayer </h1>
        <p class="naslov" style="font-size: x-large;top: -87px;">Kontakt</p>
    </div>

        
        <div class="title_img">
            
            <img src="../images/title_bgedit.jpg" alt="naslovna slika" width="1916" style="position: relative;left:-7px;top:-55px;background-color: black;">
            
        </div>
        
    </header>

    <section class="forma">
        <h2>Slanje upita</h2>
        <form>
            <label>mail: </label><input type="email" required/><br/><br/>
            <label >Ime: </label><input name="ime" type="text" required/><br/><br/>
            <label >Prezime: </label><input name="prezime" type="text"/><br/><br/>
            Spol:
            <label><input type="radio" name="spol" value="musko"/>Muško</label>
            <label><input type="radio" name="spol" value="zensko"/>Žensko</label><br/><br/>
            Upit: <br/>
            <label><textarea name="upit" cols="40" rows="20"></textarea></label><br/><br/>
            Pretplata na newsletter:
            <select name="newsletter">
                <option value="0" disabled selected>molimo odaberite</option>
                <option value="1">Da</option>
                <option value="2">Ne</option>
            </select>
            <br/><br/>
            <input type="submit" name="ok" value="Pošalji"/>
            <input type="reset" value="Reset"/>
        </form>
    </section>
    <div class="mail">
        <a href="mailto:mkralj@tvz.hr?">Upit preko maila</a>
    </div>

    <div>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3439490.9735469893!2d-85.42725508137465!3d32.6626931062402!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88f136c51d5f8157%3A0x6684bc10ec4f10e7!2sGeorgia%2C%20Sjedinjene%20Dr%C5%BEave!5e0!3m2!1shr!2shr!4v1611043904229!5m2!1shr!2shr" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
    </div>

    <footer style="position: relative; top: 250px;">Marko Kralj, JMBAG: 0246094742</footer>
    </body>
</html>
