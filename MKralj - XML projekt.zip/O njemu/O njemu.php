<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="Web stranica o John Mayeru">
        <meta name="keywords" content="John,Mayer,gitara,glazba">
        <meta name="author" content="Marko Kralj">
        <title>John Mayer</title>
        <link rel="icon" href="../images/icogif.gif" type="image/gif">
        <link rel="stylesheet" href="style.css">
        <style>
            a:link{color: purple;}
            a:visited{color: rgb(108, 29, 116);}
            a:hover{color: wheat;}
            a:active{color: violet;}
        </style>
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@300&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Teko:wght@600&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/b05e340512.js" crossorigin="anonymous"></script>
    </head>

    <body>
    <header>
        <div class="navigacija"><pre><a href="../index.php">Naslovnica</a>    <a href="../Kontakt/Kontakt.php">Kontakt</a>    <a href="#">O njemu</a>    <a href="../Novosti/Novosti.php">Novosti</a>    <a href="../Trgovina/trgovina.php">Webshop</a><?php if(isset($_SESSION["userid"])){
            echo '<a href="../logout.php">Log out</a></div>';
        }else{
            echo '<a href="../login/index.php">Login/Sign Up</a></div>';
            
        }
        ?></pre></div>
        
        <div>
        <img src="../images/ico1edit.jpg" height="200" alt="logo" class="slikica">
        <h1 class="naslov">John Mayer </h1>
        <p class="naslov" style="font-size: x-large;top: -87px;">O njemu</p>
    </div>

        
        <div class="title_img">
            
            <img src="../images/title_bg_4 (1).jpg" alt="naslovna slika" width="1920" style="position: relative;left:-7px;top:-55px;background-color: black;">
            
        </div>
        
    </header>
    
    </body>

    <main>
        <section class="rana"> <a name="rana"></a>
            <article>
                <h3>Rana karijera (1996.-1999.) <i class="fas fa-guitar"></i></h3>
                <p>Mayeru nije bilo u planu da počne studirati, ali su ga roditelji uspjeli nagovoriti te upisuje
                    se na Berklee College of Music. Nakon dva semestra se ne nagovor prijatelja sa faksa ispisuje i 
                    osnivaju dvočlani bend LoFi Masters. Nastupali su u lokalnim kafićima i klubovima poput Eddies Attic. Primijetili su
                    da imaju različite glazbene interese te su se razišli. Uz pomoć lokalnog producenta Glenn Matullo-a Mayer je snimio
                    EP Inside Wants Out.
        
                    <img src="../images/eddie.jpg" alt="eddie's attic" class="slika1" width="700px">
                </p>
            </article>
            
            <article class="desno">
                <h3>Prvi komercijalni uspjeh (2001.-2004.) <i class="fas fa-compact-disc"></i></h3><a name="prvi"></a>
                <p>Mayerova karijera se poklopila sa nastankom online glazbenog
                    tržišta te je tamo imao uspjeh.Mayer kroz Aware Records objavljuje online album
                    Room For Squares, a Aware Records je u to vrijeme sklopio ugovor sa Columbia Records. 
                    Columbia je remiksirala i ponovo objavila Room For Squares. Promijenjena je naslovnica
                    albuma te je dodana pjesma 3x5. Album je također sadržavao 4 prerađene pjesme sa 
                    Inside Wants Out.
                    <br/><br/>
                    Krajem 2002. godine iz albuma je nekoliko pjesama postalo "radio hitovi".
                    Album je dobio i kritički uspjeh. U 2003. godini Mayer dobiva Grammy nagradu 
                    za najbolji mušku vokalnu pop performansu za pjesmu Your Body Is a Wonderland.
                    <br/><br/>
                    Početkom 2003. godine objavljuje live album koji je sadržavao pjesme koje do tada
                    nisu bile snimljene. Također je polako počeo njegov talent za  sviranje gitare izlaziti
                    izlaziti na površinu. 
                    <br/><br/>
                    Iste godine izlazi album Heavier Things koji se nije prodavao kao Room For Squares
                    , ali je došao do vrha Billboard ljestvice. A pjesma Daughters je 2005. godine dobila
                    Grammy za najbolju pjesmu godine. Također je dobio nagradu za najbolje mušku vokalnu pop
                    performansu koju je prepolovio te je gornji dio nagrade dao Aliciai Keys. Snimke live nastupa
                    iz 2004. je objavio pod naslovom As/Is. 
                </p>

                <img src="../images/2003.jpg" alt="2003" width="700px">
            </article>
        </section>
            
            <section class="drugi">
                <article>
                    <h3>Promjena glazbenog smjera <i class="fas fa-music"></i></h3><a name="promjena"></a>
                    <p>
                        2003. godine Mayer je nastupao sa Buddy Guyem na njegovom koncertu te
                        je počeo surađivati sa ostalim jazz i blues glazbenicima poput Erica Claptona,
                        Herbie Hancocka, John Scofielda i B.B. Kinga. Mayer je također ušao u rap scenu
                        te je surađivao sa Kanye Wesom i Commonom. 2005. godine se udružuje sa Pinom Palladinom
                        i Steveom Jordanom te osnivaju bend John Mayer Trio. Svirali su miks rocka i bluesa
                        te su u listopadu iste godine bili predgrupa Rolling Stonesa, a u studenom su izdali 
                        live album Try!. Bend je otišao na pauzu sredinom 2006. godine.
                        <br/><br/>
                        Mayer izbacuje album Continuum koji je producirao sa Steveom Jordanom. Na albumu
                        se nalaye i pjesme Gravity i Vultures sa albuma Try!. Mayer je napomenuo da je
                        namjera bila da album bude kombinacija bluesa i popa. Za pjesmu Waiting On The World
                        To Change je dobio Grammy za najbolji pjesmu sa vokalima i za Continuum je dobio
                        Grammy za najbolji pop album. 2008. godine je izašai snimka koncerta u Los Angelesu
                        pod nazivom Where The Light is.

                        
                    </p>
                    <br/>
                    <img src="../images/2007.jpeg" alt="2007." width="600">
                </article>

                <article class="desno2">
                    <h3>Battle Studies (2009.) <i class="fas fa-record-vinyl"></i></h3><a name="battle"></a>
                    <p> Četvrti studijski album, Battle Studies, je došao do prvog mjesta na Billboard
                        200 tablici. Unatoč komercijalnom uspjehu, reakcije kritičara su bile mješovite.
                        Mayer je i sam priznao da mu to nije najbolji album. Na turneji za album je zaradio
                        45 milijuna dolara.
                    </p>
                    <img src="../images/2009.jpg" alt="2007" width="600">
                </article>
            </section>

        <aside>
            <nav>
                <ul>
                    <li><a href="#rana">Rana karijera</a></li>
                    <li><a href="#prvi">Prvi komercijalni uspjeh</a></li>
                    <li><a href="#promjena">Promjena glazbenog smjera</a></li>
                    <li><a href="#battle">Battle Studies</a></li>
                </ul>
            </nav>
        </aside>

        <iframe width="560" height="315" src="https://www.youtube.com/embed/mQ055hHdxbE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </main>
        <footer style="position: relative; top: -700px;">Marko Kralj, JMBAG: 0246094742</footer>
</html>
