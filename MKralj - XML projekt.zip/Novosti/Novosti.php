<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="Web stranica o John Mayeru">
        <meta name="keywords" content="John,Mayer,gitara,glazba">
        <meta name="author" content="Marko Kralj">
        <title>John Mayer</title>
        <link rel="icon" href="../images/icogif.gif" type="image/gif">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <link rel="stylesheet" href="style.css">
        <style>
            a:link{color: purple;}
            a:visited{color: rgb(108, 29, 116);}
            a:hover{color: wheat;}
            a:active{color: violet;}</style>
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@300&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Teko:wght@600&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/b05e340512.js" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 center">
                    <div class="header">
                    <img src="../images/ico1edit.jpg" alt="logo" class="logo" width="200px">
                    <h1 class="naslov">John Mayer</h1>
                    <h3 class="podnaslov">Novosti</h3>
                    </div>
                </div>
            </div>
        </div>
        <main>
        <section class="navigacija1">
            <nav class="navigacija1">
                <ul>
                    <li><a href="../index.php">Naslovnica</a></li>
                    <li><a href="../Kontakt/Kontakt.php">Kontakt</a></li>
                    <li><a href="../O njemu/O njemu.php">O njemu</a></li>
                    <li><a href="../Novosti/Novosti.php">Novosti</a></pre></li>
                    <li><a href="../Trgovina/trgovina.php">Webshop</a></pre></li>
                    <li><?php if(isset($_SESSION["userid"])){
            echo '<a href="../logout.php">Log out</a></div>';
        }else{
            echo '<a href="../login/index.php">Login/Sign Up</a></div>';
            
        }
        ?></li>
                </ul>
            </nav>    
        </section> 
            <br/><br/>
        
        <section class="navigacija">
            <nav>
                <ul>
                    <li><a href="#">Koncerti <i class="fas fa-calendar-day"></i></i></a></li>
                    <li><a href="#">Current Mood <i class="fab fa-instagram"></i></a></li>
                    <li><a href="#">Nova glazba <i class="fas fa-music"></i></a></li>
                </ul>
            </nav>
        </section>
        
        <div class="container float-left">
        
        
        <section class="novosti">
            <div class="row">
                <!--Prvi red-->
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="kutija">
                        <img src="../images/nov2.png" alt="nov2" width="70%">
                        <h3>John Mayer dizajnirao novi Casio sat</h3>
                        <p>John Mayer je i sam ljubitelj satova, te je bio jako obradovan
                            kad mu se Casio javio za novi G-SHOCK.
                        </p>
                        <a href="#">Cijeli članak</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="kutija">
                        <img src="../images/nas3.jpg" alt="nov3" width="70%">
                        <h3>John Mayer oktriva 9 najdražih live snimki sa Grateful Dead</h3>
                        <p>Gitarist John Mayer je gostovao kao DJ na SiriusXM te je otkrio
                            svoje favorite...
                        </p>
                        <a href="#">Cijeli članak</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="kutija">
                        <img src="../images/nov4.png" alt="nov4" width="70%">
                        
                        <h3>John Mayer slavi 43. rođendan</h3>
                        <p>Kako je Mayer proslavio rođendan u karanteni...</p>
                        <a href="#">Cijeli članak</a>
                    </div>
                </div>
                <!--Drugi red-->
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="kutija">
                        <img src="../images/nov5.png" alt="nov5" width="70%">
                        <h3>Grateful Dead "Skaedown Stream" i John Mayer pre-show</h3>
                        <p>Tjedni Shakedown Stream prijenos starih koncerata
                            vraća se u petak, 10. srpnja...</p>
                        <a href="#">Cijeli članak</a>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="kutija">
                        <img src="../images/nov6.jpg" alt="nov6" width="70%">
                        <h3>Mayer daje satove gitare na Instagramu</h3>
                        <p>John Mayer je na uživo Instagramu davao savjete svojim sljedbenicima
                            na Instagramu, a pogotovo onima koje zanima blues...
                        </p>
                        <a href="#">Cijeli članak</a>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="kutija">
                        <img src="../images/nov7.png" alt="nov7" width="70%">
                        <h3>Video za "Inside Friend"</h3>
                        <p>Leon Bridges i John Mayer su u savojim domovima snimili video za pjesmu
                            "Inside Friend"...
                        </p>
                        <a href="#">Cijeli članak</a>
                    </div>
                </div>
                <!--Treci red-->
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="kutija">
                        <img src="../images/nov8.png" alt="nov8" width="70%">
                        <h3>Leon Bridges i John Mayer su snimili pjesmu</h3>
                        <p>"Inside Friend" je kolaboracija Leon Bridgesa i John Mayera...

                        </p>
                        <a href="#">Cijeli članak</a>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="kutija">
                        <img src="../images/nov9.jpg" alt="nov9" width="70%">
                        <h3>Current Mood 3.5.2020.</h3>
                        <p>John Mayer sa gostom Cecil DeCampos zabavlja svoje pratitelje...</p>
                        <a href="#">Cijeli članak</a>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="kutija">
                        <img src="../images/nov1.jpg" alt="nov1" width="70%">
                        <h3>Current Mood 14.12.2020.</h3>
                        <p>John Mayer govori govori o novom albumu, anksioznosti,
                            koroni i više...</p>
                        <a href="#">Cijeli članak</a>
                    </div>
                </div>
            </div>
        </div>
        </section>
    </main>
        
    </body>
</html>
