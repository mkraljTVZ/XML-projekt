<?php
session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="Web stranica o John Mayeru">
        <meta name="keywords" content="John,Mayer,gitara,glazba">
        <meta name="author" content="Marko Kralj">
        <title>John Mayer</title>
        <link rel="icon" href="images/icogif.gif" type="image/gif">
        <link rel="stylesheet" href="style.css">
        <style>
            a:link{color: purple;}
            a:visited{color: rgb(108, 29, 116);}
            a:hover{color: wheat;}
            a:active{color: violet;}</style>
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@300&display=swap" rel="stylesheet">
                <link href="https://fonts.googleapis.com/css2?family=Teko:wght@600&display=swap" rel="stylesheet">
                <script src="https://kit.fontawesome.com/b05e340512.js" crossorigin="anonymous"></script>
    </head>

    <body>
    <header>
        <div class="navigacija"><pre><a href="#">Naslovnica</a>    <a href="Kontakt/kontakt.php">Kontakt</a>    <a href="O njemu/O njemu.php">O njemu</a>    <a href="Novosti/Novosti.php">Novosti</a>    <a href="Trgovina/trgovina.php">Webshop</a>
    
        <?php if(isset($_SESSION["userid"])){
            echo '<a href="logout.php">Log out</a></div>';
        }else{
            echo '<a href="login/index.php">Login/Sign Up</a></div>';
            
        }
        ?></pre> 
        
        
        <div>
        <img src="images/ico1edit.jpg" height="200" alt="logo" class="slikica">
        <h1 class="naslov">John Mayer</h1></div>
        <div class="title_img">
            <img src="images/title_bg2edit.jpg" alt="naslovna slika" width="1895" style="position: relative;left:-7px;top:-55px;">
        </div>
    </header>
    
        <!--Linkovi-->
        <div class="linkovi">
        <pre>
        <a href="#o_njemu">O njemu</a>   <a href="#glazba">Glazba i postignuća</a>   <a href="#trio">John Mayer Trio</a>   <a href="#dead_and_co">Dead & Company</a>   <a href="#tablica">Tablica</a>   
        </pre>
        </div>

        <!-- About -->
        <section>
            <div class="about">
            <a name="o_njemu"></a>
            <h2>O njemu</h2>
            <p><b>John Clayton Mayer</b>, rođen 16.10.1977. u Bridgeportu u Connecticutu, je gitarist, pjevač, skladatelj i producent.
                1997. godine je odustao od studiranja na Berkleeju i seli se Atlantu sa Clay
                Cookom sa kojim je kratko vrijeme bio u dvočlanom bendu <mark>Lo-Fi Masters</mark>. Nakon odvajanja od Cooka izdao je
                EP <i>"Inside Wants Out"</i> i nakon nastupa na festivalu <em>South by Southwest</em> 2001. godine privlači pažnju izdavačke
                kuće Aware Records i izdaje svoj prvi album <i>"Room for Squares"</i>.<br/> Jako je aktivan na društvenim mrežama preko kojih
                daje savjete za sviranje gitare i pisanje pjesama te preko kojih razgovara sa fanovima. Također ima svoj "show" <ins>Current Mood</ins> kojeg prenosi uživo
                na Instagramu. Smatra se jednim od najboljih gitarista "nove" generacije. Iako žanr njegove glazbe više vuće na pop,
                poznat je kao odličan blues gitarist sa vrhunskom tehnikom. Nastupao je sa mnogim legendama bluesa poput <strong>BB Kinga,
                Erica Claptona i Buddy Guya</strong>. 

            </p>
                
            </div>
            <div class="slika1">
                <img src="images/sec1.jpg" alt="Mayer 2001." width="700">
                </div>
        </section>

        <!--Rana karijera-->
        <section>
            <div class="glazba"><a name="glazba"></a>
                <h2>Glazba i postignuća</h2>
                <p>Analizom razvoja njegovog glazbenog opusa možemo primijetiti kako je postupno sve više implementirao blues u svoju glazbu. U njegovom trećem studijskom
                albumu <i>"Continuum"</i> se osjeti <b>veliki utjecaj bluesa</b> i solo dionice na gitari su sve kompleksnije, ali njegovo glazbeno sazrijevanje nije odvratilo 
                već postojeće fanove nego je privuklo još širu publiku. Albumi <em>"Born And Raised"</em> i <em>"Paradise Valley"</em> prelaze u druge žanrove, a to su
                folk i country, ali je to također bilo vrlo dobro prihvaćeno od kritičara i publike. Iako se u daljnjem nastavku karijere počeo vračati popu, zadržao je
                solaže u kojima se osjeti veliki utjecaj bluesa. <br/>
                Kroz svoju karijeru je uz brojne nagrade dobio i <mark>7 Grammy nagrada</mark> te je bio nominiran za njih još 11.<br/>
                Eric Clapton ga je u jednom intervjuu nazvao majstorom gitare nakon iskustva snimanja sa njim.
                </p>
            </div>
            <div class="slika2"><img src="images/jm2004.jpg" alt="Mayer 2004." height="500"></div>
        </section>

        <!--Promjena smjera-->
        <section>
            <div class="trio"><a name="trio"></a>
                <h2>John Mayer Trio</h2>
                <p>Mayer je u proljeće 2005. godine osnovao bend <b>John Mayer Trio</b> sa basistom <strong>Pino Palladinom</strong> i bubnjarom <strong>Steve Jordanom</strong>.
                Najviše su svirali <ins>blues i rock</ins> glazbu. Trio je te godine bio predgrupa na turneji <mark>Rolling Stonesa</mark>, a iste godine u studenom su izdali live album <i>"Try"</i>.
                Uz svoju originalnu glazbu su radili i obrade blues klasika. Bend je otišao na pauzu sredinom 2006. godine. Okupili su se još za nekoliko prilika, a zadnji
                zajednički nastup su imali 2014. godine. 
                </p>
            </div>
            <div class="slika3">
                <img src="images/trio.jpg" alt="John Mayer Trio" width="700">
            </div>
        </section>

        <!--Operacija i povlačenje iz javnosti-->
        <section>
            <div class="dead_and_co"><a name="dead_and_co"></a>
                <h2>Dead & Company</h2>
                <p>U veljači 2015. godine, gitarist benda Grateful Dead <b>Bob Weir</b> i <b>John Mayer</b> su osnovali bend <strong>Dead & Company</strong> koji se uz njih sastoji još od <b>Mickey Harta</b>, <b>Bill Kreutzmanna</b>,
                    <b>Oteil Burbridgea</b> i <b>Jeff Chimentija</b>. Na početku su najavili samo jedan koncert na Madison Square Gardenu, ali uskoro su najavili da idu na turneju.
                    <ins>Turneja je bila dobro prihvaćena od strane kritičara i fanova</ins>. Zbog nastupa sa Dead & Company John Mayer je odgodio rad na novom albumu do siječnja 2016. godine.
                    Od 2015. do 2019. su svake godine imali turneju, ali turneju za 2020. godinu su odgodili zbog epidemioloških razloga. Nisu izdali nijedan album, ali je snimka
                    svakog koncerta izdana (ili će biti izdana) na CD-u, Spotifyu i ostalim servisima za streaming glazbe te na njihovoj <b><a href="https://livedead.co/">"livedead.co"</a></b> web stranici.

                </p>
            </div>
            <div class="slika4">
                <img src="images/deadandco.jpg" alt="John Mayer i Bob Weir" width="650">
            </div>
        </section>
        <div class="tablice"><a name="tablica"></a>
            <table style="width:900px;height:900px;text-align: center;">
                <!--Prvi redak-->
                <caption>Neki od albuma</caption>
                <tr>
                    <td>Naslovnica</td>
                    <td>Ime</td>
                    <td>Godina</td>
                    <td>Vrsta</td>
                </tr>

                <!--Drugi redak-->
                <tr>
                    <td><img src="images/album1.jpg" alt="The Search For Everything Cover" width="200"></td>
                    <td>The Search For Everything </td>
                    <td>2017.</td>
                    <td>Studijski album</td>
                </tr>

                <!--Treci redak-->
                <tr>
                    <td><img src="images/album3.jpg" alt="Where The Light Is Cover" width="200"></td>
                    <td>Where The Light Is</td>
                    <td>2008.</td>
                    <td rowspan="3">Live album</td>
                </tr>

                <!--Cetvrti redak-->
                <tr>
                    <td><img src="images/album5.jpg" alt="" width="200"></td>
                    <td>As/Is: Philadelphia, PA/Hartford, CT - 8/14-8/15/04</td>
                    <td>2004.</td>
                    <!--<td>4</td>-->
                </tr>

                <!--Peti redak-->
                <tr>
                    <td><img src="images/album4.jpg" alt="As/Is2" width="200"></td>
                    <td>As/Is: Houston, TX - 7/24/04</td>
                    <td>2004.</td>
                    <!--<td>4</td>-->
                </tr>
            </table>
        </div>
        <footer>Marko Kralj, JMBAG: 0246094742</footer>
    </body>
    
    
</html>