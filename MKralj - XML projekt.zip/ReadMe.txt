Login forma je template sa neta, ali sav php sam ja napravio. Ostali html i css je od projekta iz 1. semestra.
Za pokretanje je potrebno upaliti xampp (apache).
Kod registracije se u xml upisuju podaci ako vec ne postoji korisnik koji ima isti mail i username. 
Kod prijave provjerava se postoji li korisnik sa unesenim mailom i lozinkom. Ako postoji, vraca korisnika na pocetnu stranicu
i trebalo bi umjesto opcije za prijavu biti ponudena odjava, ali session nazalost ne radi.
U url-u pise poruka o vrsti greske pri registraciji/prijavi ili o uspjesnoj registraciji/prijavi.